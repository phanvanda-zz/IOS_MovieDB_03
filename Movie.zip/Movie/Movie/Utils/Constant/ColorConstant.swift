//
//  ColorConstant.swift
//  Movie
//
//  Created by TranCuong on 8/3/18.
//  Copyright © 2018 Tran Cuong. All rights reserved.
//
import Foundation
import UIKit

class ColorConstant {
    static let lineColor = UIColor(r: 220, g: 220, b: 220)
    static let textNoti = UIColor(r: 255, g: 138, b: 247)
}
