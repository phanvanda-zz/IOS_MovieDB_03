//
//  SizeConstant.swift
//  Movie
//
//  Created by Da on 8/11/18.
//  Copyright © 2018 Tran Cuong. All rights reserved.
//

import Foundation
import UIKit

struct sizeCollectionView {
    static let spaceItem = CGFloat(8)
}

struct sizeTableView {
    static let heighTableViewCell: CGFloat = 160
}
