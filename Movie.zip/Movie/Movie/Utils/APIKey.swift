//
//  APIKey.swift
//  Movie
//
//  Created by Da on 7/31/18.
//  Copyright © 2018 Tran Cuong. All rights reserved.
//

import Foundation

struct APIKey {
    static let key = "c80ec9d27d4803e8381e5574720199e2"
}
